# VPluz STAR MAP

Static personality quiz for VPluz Community. Designed to run directly on GitHub Pages.

## Setup

1. Upload this folder to a GitHub repository.
2. Put your Discord QR image at `assets/discord-qr.png`.
3. Open `script.js` and replace `DISCORD_URL` with the real VPluz Discord invite URL.
4. Enable GitHub Pages from Settings → Pages → Deploy from branch → `main`.

No database, server, login, analytics, or API is required. Quiz scoring happens entirely in the visitor's browser.

## Files

- `index.html` — app shell
- `style.css` — design and responsive layout
- `script.js` — quiz flow, scoring, result, share and Discord popup
- `data/questions.js` — 24 questions and scoring
- `data/stars.js` — 12 star profiles and compatibility
- `assets/discord-qr.png` — replace with VPluz Discord QR
