const app = document.getElementById('app');
const state = { index: 0, answers: [], scores: {}, result: null };
const DISCORD_URL = 'https://discord.gg/REPLACE_ME';
const QR_PATH = 'assets/discord-qr.png';

function resetScores(){ state.scores = Object.fromEntries(Object.keys(STAR_TYPES).map(k=>[k,0])); }
resetScores();

function starsMarkup(count){ return '✦'.repeat(count) + '☆'.repeat(5-count); }
function escapeHtml(str){ return String(str).replace(/[&<>'"]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }

function renderLanding(){
  app.innerHTML = `
    <section class="screen landing fade-in">
      <div class="brand">VPLUZ <span>STAR MAP</span></div>
      <div class="hero-orb"><div class="orb-ring r1"></div><div class="orb-ring r2"></div><div class="orb-core">✦</div></div>
      <p class="eyebrow">A VPLUZ COMMUNITY EXPERIENCE</p>
      <h1>Find the light<br><em>that belongs to you.</em></h1>
      <p class="lead">ทุกคนมีแสงเป็นของตัวเอง<br>แล้วแสงของคุณเป็นแบบไหน?</p>
      <button class="primary" id="startBtn">BEGIN THE JOURNEY <span>→</span></button>
      <p class="micro">24 questions · 12 stars · no right or wrong answers</p>
    </section>`;
  document.getElementById('startBtn').onclick = startQuiz;
}

function startQuiz(){ state.index=0; state.answers=[]; resetScores(); renderQuestion(); }

function renderQuestion(){
  const q=QUESTIONS[state.index];
  const progress=((state.index)/QUESTIONS.length)*100;
  app.innerHTML=`
    <section class="screen quiz fade-in">
      <header class="quiz-head"><button class="ghost" id="quitBtn">VPLUZ STAR MAP</button><span>${String(state.index+1).padStart(2,'0')} / ${QUESTIONS.length}</span></header>
      <div class="progress"><i style="width:${progress}%"></i></div>
      <div class="question-wrap">
        <p class="eyebrow">QUESTION ${String(state.index+1).padStart(2,'0')}</p>
        <h2>${escapeHtml(q.text)}</h2>
        <div class="answers">${q.answers.map((a,i)=>`<button class="answer" data-i="${i}"><span class="answer-star">${['☄','☾','✦','◌','★'][i%5]}</span><span>${escapeHtml(a[0])}</span><span class="arrow">→</span></button>`).join('')}</div>
      </div>
    </section>`;
  document.getElementById('quitBtn').onclick=renderLanding;
  document.querySelectorAll('.answer').forEach(btn=>btn.onclick=()=>chooseAnswer(Number(btn.dataset.i)));
}

function chooseAnswer(i){
  const answer=QUESTIONS[state.index].answers[i];
  state.answers.push(i);
  for(const [star,pts] of Object.entries(answer[1])) if(state.scores[star]!==undefined) state.scores[star]+=pts;
  state.index++;
  if(state.index>=QUESTIONS.length) finishQuiz(); else renderQuestion();
}

function finishQuiz(){
  const ranked=Object.entries(state.scores).sort((a,b)=>b[1]-a[1]);
  const top=ranked[0][1];
  const tied=ranked.filter(x=>x[1]===top);
  let winner=tied[0][0];
  if(tied.length>1){
    const recent=state.answers.slice(-8);
    const recentCounts={};
    recent.forEach((ans,idx)=>{
      const q=QUESTIONS[QUESTIONS.length-8+idx];
      if(q){ Object.entries(q.answers[ans][1]).forEach(([s,p])=>recentCounts[s]=(recentCounts[s]||0)+p); }
    });
    winner=tied.sort((a,b)=>(recentCounts[b[0]]||0)-(recentCounts[a[0]]||0))[0][0];
  }
  state.result=winner;
  renderReveal();
}

function renderReveal(){
  const s=STAR_TYPES[state.result];
  app.innerHTML=`<section class="screen reveal fade-in"><div class="reveal-stars">✦　·　✧　　·　✦　　·　✧</div><p class="eyebrow">YOUR STAR HAS BEEN FOUND</p><div class="reveal-symbol" style="--c1:${s.colors[0]};--c2:${s.colors[1]}">${s.icon}</div><p class="reveal-name">${s.name}</p><div class="reveal-line"></div><p class="micro">Mapping your light...</p></section>`;
  setTimeout(renderResult,1800);
}

function renderResult(){
  const s=STAR_TYPES[state.result];
  const second=Object.entries(state.scores).filter(x=>x[0]!==state.result).sort((a,b)=>b[1]-a[1])[0][0];
  const traits=Object.values(state.scores).sort((a,b)=>b-a);
  const max=Math.max(...traits)||1;
  const bars= s.core.map((x,i)=>`${x}<b><i style="width:${Math.max(38,Math.min(96,68+(state.scores[state.result]/Math.max(1,QUESTIONS.length))*20-i*7))}%"></i></b>`).join('');
  app.innerHTML=`
  <section class="screen result fade-in" style="--c1:${s.colors[0]};--c2:${s.colors[1]}">
    <header class="result-head"><div class="brand">VPLUZ <span>STAR MAP</span></div><button class="ghost" id="restart">RETAKE</button></header>
    <div class="result-grid">
      <div class="star-art"><div class="big-orbit"></div><div class="star-glow">${s.icon}</div><div class="constellation-dots">·　✦　　·　✧　·</div></div>
      <div class="result-copy">
        <p class="eyebrow">YOUR STAR</p><h1>${s.name}</h1><h3>${s.thai}</h3>
        <blockquote>“${s.quote}”</blockquote>
        <p class="description">${s.description}</p>
        <div class="rarity"><span>${starsMarkup(s.rarityStars)}</span><strong>${s.rarity}</strong><small>A designed rarity — not a ranking of value.</small></div>
        <div class="core">${bars}</div>
        <div class="result-actions"><button class="primary" id="shareBtn">✦ SHARE YOUR STAR</button><button class="secondary" id="communityBtn">JOIN VPLUZ COMMUNITY</button></div>
      </div>
    </div>
    <div class="result-lower">
      <article><p class="eyebrow">YOUR STRENGTHS</p><div class="chips">${s.strengths.map(x=>`<span>${x}</span>`).join('')}</div></article>
      <article><p class="eyebrow">WATCH YOUR ORBIT</p><div class="chips muted">${s.caution.map(x=>`<span>${x}</span>`).join('')}</div></article>
      <article><p class="eyebrow">COSMIC CONNECTIONS</p><div class="matches">${s.compatible.map(id=>{const x=STAR_TYPES[id]; return `<div class="match"><span>${x.icon}</span><div><strong>${x.name}</strong><small>${x.thai}</small></div></div>`}).join('')}</div></article>
    </div>
  </section>`;
  document.getElementById('restart').onclick=startQuiz;
  document.getElementById('shareBtn').onclick=shareResult;
  document.getElementById('communityBtn').onclick=()=>showCommunity(true);
}

async function shareResult(){
  const s=STAR_TYPES[state.result];
  const text=`✦ I discovered my star: ${s.name}\n${s.thai}\n\n${s.quote}\n\nVPluz STAR MAP — Find the light that belongs to you.`;
  if(navigator.share){ try{ await navigator.share({title:'VPluz STAR MAP',text}); return; }catch(e){} }
  try{ await navigator.clipboard.writeText(text); alert('คัดลอกผลลัพธ์แล้ว'); }catch(e){ alert(text); }
}

function showCommunity(auto=false){
  const existing=document.querySelector('.modal'); if(existing) existing.remove();
  const s=STAR_TYPES[state.result];
  const safeUrl=DISCORD_URL.includes('REPLACE_ME')?'#':DISCORD_URL;
  document.body.insertAdjacentHTML('beforeend',`
  <div class="modal" role="dialog" aria-modal="true">
    <div class="modal-backdrop"></div>
    <div class="modal-card">
      <button class="modal-close" id="closeModal">×</button>
      <div class="modal-star">${s.icon}</div>
      <p class="eyebrow">YOUR JOURNEY DOESN'T END HERE</p>
      <h2>Meet the other stars.</h2>
      <p>มาพบกับเหล่าดวงดาวดวงอื่นใน<br><strong>VPluz Community</strong></p>
      <img class="qr" src="${QR_PATH}" alt="VPluz Community Discord QR Code" onerror="this.style.display='none';this.nextElementSibling.style.display='block';">
      <div class="qr-fallback">ใส่ QR Code Discord ของ VPluz ที่<br><code>assets/discord-qr.png</code></div>
      <a class="primary link-btn" href="${safeUrl}" target="_blank" rel="noopener">JOIN VPLUZ COMMUNITY ↗</a>
      <button class="later" id="closeLater">Maybe later</button>
    </div>
  </div>`);
  document.getElementById('closeModal').onclick=closeModal;
  document.getElementById('closeLater').onclick=closeModal;
  document.querySelector('.modal-backdrop').onclick=closeModal;
}
function closeModal(){document.querySelector('.modal')?.remove();}

renderLanding();
